#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include <MAX30105.h>
#include "heartRate.h"  // For checkForBeat from SparkFun library

// ------------------- OLED Setup -------------------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 32
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ------------------- Servo Setup -------------------
Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);
#define SERVO_MIN 150
#define SERVO_MAX 600
#define SERVO_GAMOT_A 0
#define SERVO_GAMOT_B 1
#define SERVO_DOSAGE  2

// ------------------- Ultrasonic -------------------
#define TRIG_PIN 5
#define ECHO_PIN 27

// ------------------- Tripwire / LDR -------------------
#define LASER1_PIN 12
#define LASER2_PIN 13
#define LDR1_PIN 14
#define LDR2_PIN 26

// ------------------- Buzzer -------------------
#define BUZZER_PIN 25

// ------------------- DHT11 -------------------
#define DHTPIN 33
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// ------------------- MAX30102 -------------------
MAX30105 particleSensor;
const byte RATE_SIZE = 4;
byte rates[RATE_SIZE];
byte rateSpot = 0;
long lastBeat = 0;
float beatsPerMinute;
int beatAvg = 0;

// ------------------- Sensor phase -------------------
unsigned long sensorStartTime = 0;
bool sensorPhaseDone = false;
const unsigned long SENSOR_PHASE_DURATION = 30000; // 30 sec

// ------------------- Dosage -------------------
int dosageCurrentAngle = 0;
bool dosageOpened = false;

// ------------------ Task Queue ------------------
enum TaskType { GAMOT_A, GAMOT_B };
TaskType taskQueue[] = {GAMOT_A, GAMOT_B, GAMOT_A};
int queueLength = 3;
int currentTask = 0;

// ------------------- Data Structures -------------------
struct DHTData {
  float temperature;
  float humidity;
  bool valid;
};

struct MAX30102Data {
  int heartRate;
  int spo2;
  bool fingerDetected;
  bool valid;
};

// ------------------- Setup -------------------
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);

  // OLED init
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 allocation failed");
    for (;;);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Initializing...");
  display.display();

  // Servo init
  pwm.begin();
  pwm.setPWMFreq(50);
  setServoAngle(SERVO_GAMOT_A, 0);
  setServoAngle(SERVO_GAMOT_B, 0);
  setServoAngle(SERVO_DOSAGE, 0);

  // Pins init
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LASER1_PIN, OUTPUT);
  pinMode(LASER2_PIN, OUTPUT);
  digitalWrite(LASER1_PIN, HIGH);
  digitalWrite(LASER2_PIN, HIGH);
  pinMode(LDR1_PIN, INPUT);
  pinMode(LDR2_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  // DHT11 init
  dht.begin();

  // MAX30102 init
  setupMAX30102();

  Serial.println("System Ready.");
}

// ------------------- Main Loop -------------------
void loop() {
  // -------- SENSOR PHASE (30 sec) --------
  if (!sensorPhaseDone) {
    if (sensorStartTime == 0) sensorStartTime = millis();

    MAX30102Data pulseData = readMAX30102();
    DHTData dhtData = readDHT11();

    // Serial monitor output
    Serial.print("[Sensor Phase] HR: ");
    Serial.print(pulseData.fingerDetected ? pulseData.heartRate : 0);
    Serial.print(" bpm, SpO2: ");
    Serial.print(pulseData.fingerDetected ? pulseData.spo2 : 0);
    Serial.print("% | Temp: ");
    Serial.print(dhtData.temperature);
    Serial.print(" C, Hum: ");
    Serial.println(dhtData.humidity);

    // OLED display
    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println("Health Check");
    display.drawLine(0, 10, 127, 10, SSD1306_WHITE);

    display.setCursor(0, 14);
    display.print("HR: ");
    display.print(pulseData.fingerDetected ? pulseData.heartRate : 0);
    display.println(" bpm");

    display.setCursor(0, 24);
    display.print("SpO2: ");
    display.print(pulseData.fingerDetected ? pulseData.spo2 : 0);
    display.println("%");

    display.setCursor(64, 14);
    display.print("T: ");
    display.print(dhtData.valid ? dhtData.temperature : 0);
    display.println("C");

    display.setCursor(64, 24);
    display.print("H: ");
    display.print(dhtData.valid ? dhtData.humidity : 0);
    display.println("%");

    display.display();

    if (millis() - sensorStartTime >= SENSOR_PHASE_DURATION) {
      sensorPhaseDone = true;
      Serial.println("Sensor phase done. Starting task queue...");
    }

    delay(200);
    return;
  }

  // -------- TASK QUEUE PHASE --------
  if (currentTask < queueLength) {
    TaskType task = taskQueue[currentTask];
    switch (task) {
      case GAMOT_A:
        Serial.println("[Task Queue] Starting Gamot A");
        gamotAControlTask();
        Serial.println("[Task Queue] Finished Gamot A");
        break;
      case GAMOT_B:
        Serial.println("[Task Queue] Starting Gamot B");
        gamotBControlTask();
        Serial.println("[Task Queue] Finished Gamot B");
        break;
    }
    currentTask++;
  } else {
    dosageHatchControlTask();
    updateBuzzer();

    // OLED dosage display
    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println("Dosage Ready");
    display.setCursor(90, 0);
    display.print(dosageCurrentAngle == 90 ? "OPEN" : "CLOSED");
    display.display();

    // Serial output
    Serial.print("[Dosage Hatch] Status: ");
    Serial.println(dosageCurrentAngle == 90 ? "OPEN" : "CLOSED");
  }
}

// ------------------- Servo Control -------------------
void setServoAngle(int channel, int angle) {
  int pulse = map(angle, 0, 180, SERVO_MIN, SERVO_MAX);
  pwm.setPWM(channel, 0, pulse);
}

// ------------------- Task Functions -------------------
void gamotAControlTask() {
  Serial.println("[Gamot A] Opening gate");
  setServoAngle(SERVO_GAMOT_A, 90);
  while (readTripwire(LDR1_PIN) == 0) delay(20);
  Serial.println("[Gamot A] Object passed → Closing gate");
  setServoAngle(SERVO_GAMOT_A, 0);
}

void gamotBControlTask() {
  Serial.println("[Gamot B] Opening gate");
  setServoAngle(SERVO_GAMOT_B, 90);
  while (readTripwire(LDR2_PIN) == 0) delay(20);
  Serial.println("[Gamot B] Object passed → Closing gate");
  setServoAngle(SERVO_GAMOT_B, 0);
}

// ------------------- Dosage Hatch -------------------
void dosageHatchControlTask() {
  float dist = readDistanceCM();

  if (dist > 0 && dist <= 4.0) {
    if (!dosageOpened) {
      Serial.println("[Dosage Hatch] Medicine detected → Opening");
      dosageOpened = true;
      digitalWrite(BUZZER_PIN, LOW);
    }
    setServoAngle(SERVO_DOSAGE, 90);
    dosageCurrentAngle = 90;
  } else {
    if (dosageCurrentAngle != 0) {
      setServoAngle(SERVO_DOSAGE, 0);
      dosageCurrentAngle = 0;
    }
  }
}

// ------------------- Sensors & Helpers -------------------
int readTripwire(int ldrPin) {
  return digitalRead(ldrPin) == LOW ? 1 : 0;
}

float readDistanceCM() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return -1;
  return duration * 0.0343 / 2;
}

void updateBuzzer() {
  static unsigned long lastBuzz = 0;
  static bool buzzerState = false;
  unsigned long currentMillis = millis();
  if (!dosageOpened && currentMillis - lastBuzz >= 200) {
    lastBuzz = currentMillis;
    buzzerState = !buzzerState;
    digitalWrite(BUZZER_PIN, buzzerState);
  }
}

// ------------------- DHT11 -------------------
DHTData readDHT11() {
  DHTData data;
  data.temperature = dht.readTemperature();
  data.humidity = dht.readHumidity();
  data.valid = !(isnan(data.temperature) || isnan(data.humidity));
  return data;
}

// ------------------- MAX30102 -------------------
void setupMAX30102() {
  if (!particleSensor.begin(Wire, I2C_SPEED_STANDARD)) {
    Serial.println("MAX30102 not found!");
    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("MAX30102 ERROR!");
    display.display();
    while (1);
  }

  particleSensor.setup(0x1F, 4, 2, 100, 411, 4096);
  particleSensor.setPulseAmplitudeRed(0x1F);
  particleSensor.setPulseAmplitudeGreen(0);

  Serial.println("MAX30102 initialized.");
}

MAX30102Data readMAX30102() {
  MAX30102Data data;
  data.fingerDetected = false;
  data.valid = false;
  data.heartRate = 0;
  data.spo2 = 0;

  long irValue = particleSensor.getIR();

  if (irValue > 50000) {  // Finger detected threshold
    data.fingerDetected = true;

    // Heart rate detection using library's checkForBeat function
    if (checkForBeat(irValue) == true) {
      long delta = millis() - lastBeat;
      lastBeat = millis();
      beatsPerMinute = 60000.0f / (float)delta;

      if (beatsPerMinute > 30 && beatsPerMinute < 200) {
        rates[rateSpot++] = (byte)beatsPerMinute;
        rateSpot %= RATE_SIZE;

        // Calculate average
        beatAvg = 0;
        for (byte x = 0; x < RATE_SIZE; x++) {
          beatAvg += rates[x];
        }
        beatAvg /= RATE_SIZE;
        
        data.heartRate = beatAvg;
        data.valid = true;
      }
    }

    // Simple SpO2 estimation
    long redValue = particleSensor.getRed();
    
    if (redValue > 10000 && irValue > 10000) {
      // Simple SpO2 estimation based on R ratio
      float ratio = (float)redValue / (float)irValue;
      int spo2Estimate = 110 - 25 * ratio;
      
      if (spo2Estimate > 85 && spo2Estimate < 100) {
        data.spo2 = spo2Estimate;
      } else {
        data.spo2 = 98; // Default reasonable value
      }
    }
  } else {
    // Reset when finger removed
    rateSpot = 0;
    beatAvg = 0;
    for (byte x = 0; x < RATE_SIZE; x++) {
      rates[x] = 0;
    }
  }

  return data;
}