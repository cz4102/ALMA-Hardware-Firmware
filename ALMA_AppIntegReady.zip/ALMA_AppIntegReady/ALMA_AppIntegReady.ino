#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include <MAX30105.h>
#include "heartRate.h"
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// =============== BLE SERVICE UUIDs ===============
// Main Service UUID
#define SERVICE_UUID "4fafc201-1fb5-459e-8fcc-c5c9c331914b"

// Characteristic UUIDs
#define CHAR_SENSOR_DATA_UUID    "beb5483e-36e1-4688-b7f5-ea07361b26a8"  // Read/Notify: Health sensor data
#define CHAR_SYSTEM_STATUS_UUID  "1c95d5e3-d8f7-413a-bf3d-7a2e5d7be87e"  // Read/Notify: System status
#define CHAR_COMMAND_UUID        "d8de624e-140f-4a22-8594-e2216b84a5f2"  // Write: Commands from app
#define CHAR_SCHEDULE_UUID       "a3c87500-8ed3-4bdf-8a39-a01bebede295"  // Write: Schedule configuration
#define CHAR_MANUAL_CONTROL_UUID "7d2ea78a-1f9d-4c4a-9a5a-e0e0e7e6b8c9"  // Write: Manual servo control

// =============== OLED Setup ===============
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 32
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// =============== Servo Setup ===============
Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);
#define SERVO_MIN 150
#define SERVO_MAX 600
#define SERVO_GAMOT_A 0
#define SERVO_GAMOT_B 1
#define SERVO_DOSAGE  2

// =============== Ultrasonic ===============
#define TRIG_PIN 5
#define ECHO_PIN 27

// =============== Tripwire / LDR ===============
#define LASER1_PIN 12
#define LASER2_PIN 13
#define LDR1_PIN 14
#define LDR2_PIN 26

// =============== Buzzer ===============
#define BUZZER_PIN 25

// =============== DHT11 ===============
#define DHTPIN 33
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// =============== MAX30102 ===============
MAX30105 particleSensor;
const byte RATE_SIZE = 4;
byte rates[RATE_SIZE];
byte rateSpot = 0;
long lastBeat = 0;
float beatsPerMinute;
int beatAvg = 0;

// =============== BLE Variables ===============
BLEServer* pServer = NULL;
BLECharacteristic* pSensorDataChar = NULL;
BLECharacteristic* pSystemStatusChar = NULL;
BLECharacteristic* pCommandChar = NULL;
BLECharacteristic* pScheduleChar = NULL;
BLECharacteristic* pManualControlChar = NULL;
bool deviceConnected = false;
bool oldDeviceConnected = false;
unsigned long lastStatusBroadcast = 0;

// =============== Dosage ===============
int dosageCurrentAngle = 0;
bool dosageOpened = false;

// =============== Task Queue ===============
enum TaskType { GAMOT_A, GAMOT_B };
struct ScheduleItem {
  TaskType taskType;
  unsigned long scheduledTime; // Unix timestamp or millis offset
  bool executed;
};

ScheduleItem taskQueue[20]; // Max 20 scheduled tasks
int queueLength = 0;
int currentTask = 0;
bool manualMode = false; // Flag for manual control from app
bool queueRunning = false; // Flag to control queue execution

// =============== Data Structures ===============
struct DHTData {
  float temperature;
  float humidity;
  bool valid;
};

struct MAX30102Data {
  int heartRate;
  int spo2;
  bool fingerDetected;
  bool valid;
};

// =============== FORWARD DECLARATIONS ===============
void handleCommand(String cmd);
void handleSchedule(String schedule);
void handleManualControl(String control);
void broadcastSensorData();
void broadcastSystemStatus(String status);
void setServoAngle(int channel, int angle);
float readDistanceCM();
DHTData readDHT11();
MAX30102Data readMAX30102();
void setupMAX30102();
void gamotAControlTask();
void gamotBControlTask();
void dosageHatchControlTask();
int readTripwire(int ldrPin);
void updateBuzzer();
void displayBLEStatus();
void setupBLE();

// =============== BLE Callbacks ===============
class MyServerCallbacks: public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    deviceConnected = true;
    Serial.println("BLE Client Connected");
  }

  void onDisconnect(BLEServer* pServer) {
    deviceConnected = false;
    Serial.println("BLE Client Disconnected");
  }
};

// Command Characteristic Callback
class CommandCallbacks: public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String value = pCharacteristic->getValue().c_str();
    if (value.length() > 0) {
      Serial.print("Command Received: ");
      Serial.println(value);
      
      // Parse command (format: "CMD:parameter")
      handleCommand(value);
    }
  }
};

// Schedule Characteristic Callback
class ScheduleCallbacks: public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String value = pCharacteristic->getValue().c_str();
    if (value.length() > 0) {
      Serial.print("Schedule Received: ");
      Serial.println(value);
      
      // Parse schedule (format: "TASK:timestamp,TASK:timestamp,...")
      handleSchedule(value);
    }
  }
};

// Manual Control Callback
class ManualControlCallbacks: public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String value = pCharacteristic->getValue().c_str();
    if (value.length() > 0) {
      Serial.print("Manual Control: ");
      Serial.println(value);
      
      // Parse manual control (format: "SERVO:channel:angle")
      handleManualControl(value);
    }
  }
};

// =============== Setup ===============
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);

  // OLED init
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 allocation failed");
    for (;;);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Initializing...");
  display.display();

  // Servo init
  pwm.begin();
  pwm.setPWMFreq(50);
  setServoAngle(SERVO_GAMOT_A, 0);
  setServoAngle(SERVO_GAMOT_B, 0);
  setServoAngle(SERVO_DOSAGE, 0);

  // Pins init
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LASER1_PIN, OUTPUT);
  pinMode(LASER2_PIN, OUTPUT);
  digitalWrite(LASER1_PIN, HIGH);
  digitalWrite(LASER2_PIN, HIGH);
  pinMode(LDR1_PIN, INPUT);
  pinMode(LDR2_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  // DHT11 init
  dht.begin();

  // MAX30102 init
  setupMAX30102();

  // BLE init
  setupBLE();

  Serial.println("System Ready - BLE Enabled");
  displayBLEStatus();
}

// =============== BLE Setup ===============
void setupBLE() {
  BLEDevice::init("ESP32_HealthMonitor");
  
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  // Sensor Data Characteristic (Read + Notify)
  pSensorDataChar = pService->createCharacteristic(
    CHAR_SENSOR_DATA_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );
  pSensorDataChar->addDescriptor(new BLE2902());

  // System Status Characteristic (Read + Notify)
  pSystemStatusChar = pService->createCharacteristic(
    CHAR_SYSTEM_STATUS_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );
  pSystemStatusChar->addDescriptor(new BLE2902());

  // Command Characteristic (Write)
  pCommandChar = pService->createCharacteristic(
    CHAR_COMMAND_UUID,
    BLECharacteristic::PROPERTY_WRITE
  );
  pCommandChar->setCallbacks(new CommandCallbacks());

  // Schedule Characteristic (Write)
  pScheduleChar = pService->createCharacteristic(
    CHAR_SCHEDULE_UUID,
    BLECharacteristic::PROPERTY_WRITE
  );
  pScheduleChar->setCallbacks(new ScheduleCallbacks());

  // Manual Control Characteristic (Write)
  pManualControlChar = pService->createCharacteristic(
    CHAR_MANUAL_CONTROL_UUID,
    BLECharacteristic::PROPERTY_WRITE
  );
  pManualControlChar->setCallbacks(new ManualControlCallbacks());

  pService->start();

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);
  pAdvertising->setMinPreferred(0x12);
  BLEDevice::startAdvertising();
  
  Serial.println("BLE Service Started - Advertising...");
}

// =============== Command Handler ===============
void handleCommand(String cmd) {
  // Commands format: "CMD:parameter"
  // START_QUEUE - Start task queue execution
  // STOP_QUEUE - Stop/pause task queue
  // RESET_QUEUE - Reset to beginning
  // READ_SENSORS - Read DHT11 and MAX30102, broadcast data
  // BUZZER:ON/OFF - Control buzzer
  // OPEN_DOSAGE - Manually open dosage hatch
  // CLOSE_DOSAGE - Manually close dosage hatch
  // MANUAL_MODE:ON/OFF - Enable/disable manual mode
  
  if (cmd.startsWith("START_QUEUE")) {
    currentTask = 0;
    queueRunning = true;
    Serial.println("Queue started from app");
    broadcastSystemStatus("QUEUE_STARTED");
    
  } else if (cmd.startsWith("STOP_QUEUE")) {
    queueRunning = false;
    Serial.println("Queue stopped from app");
    broadcastSystemStatus("QUEUE_STOPPED");
    
  } else if (cmd.startsWith("RESET_QUEUE")) {
    currentTask = 0;
    queueRunning = false;
    for (int i = 0; i < queueLength; i++) {
      taskQueue[i].executed = false;
    }
    Serial.println("Queue reset from app");
    broadcastSystemStatus("QUEUE_RESET");
    
  } else if (cmd.startsWith("READ_SENSORS")) {
    Serial.println("Reading sensors on demand...");
    broadcastSensorData();
    broadcastSystemStatus("SENSORS_READ");
    
  } else if (cmd.startsWith("BUZZER:ON")) {
    digitalWrite(BUZZER_PIN, HIGH);
    broadcastSystemStatus("BUZZER_ON");
    
  } else if (cmd.startsWith("BUZZER:OFF")) {
    digitalWrite(BUZZER_PIN, LOW);
    broadcastSystemStatus("BUZZER_OFF");
    
  } else if (cmd.startsWith("OPEN_DOSAGE")) {
    setServoAngle(SERVO_DOSAGE, 90);
    dosageCurrentAngle = 90;
    broadcastSystemStatus("DOSAGE_OPENED");
    
  } else if (cmd.startsWith("CLOSE_DOSAGE")) {
    setServoAngle(SERVO_DOSAGE, 0);
    dosageCurrentAngle = 0;
    broadcastSystemStatus("DOSAGE_CLOSED");
    
  } else if (cmd.startsWith("MANUAL_MODE:ON")) {
    manualMode = true;
    broadcastSystemStatus("MANUAL_MODE_ON");
    
  } else if (cmd.startsWith("MANUAL_MODE:OFF")) {
    manualMode = false;
    broadcastSystemStatus("MANUAL_MODE_OFF");
  }
}

// =============== Schedule Handler ===============
void handleSchedule(String schedule) {
  // Schedule format: "TASK_TYPE:timestamp,TASK_TYPE:timestamp,..."
  // Example: "A:1699999999,B:1700000010,A:1700000020"
  // A = GAMOT_A, B = GAMOT_B
  
  queueLength = 0;
  int startIdx = 0;
  
  while (startIdx < schedule.length() && queueLength < 20) {
    int separatorIdx = schedule.indexOf(',', startIdx);
    if (separatorIdx == -1) separatorIdx = schedule.length();
    
    String item = schedule.substring(startIdx, separatorIdx);
    int colonIdx = item.indexOf(':');
    
    if (colonIdx != -1) {
      String taskStr = item.substring(0, colonIdx);
      String timeStr = item.substring(colonIdx + 1);
      
      TaskType task = (taskStr == "A") ? GAMOT_A : GAMOT_B;
      unsigned long timestamp = timeStr.toInt();
      
      taskQueue[queueLength] = {task, timestamp, false};
      queueLength++;
    }
    
    startIdx = separatorIdx + 1;
  }
  
  currentTask = 0;
  queueRunning = false; // Don't auto-start, wait for START_QUEUE command
  
  Serial.print("Schedule updated: ");
  Serial.print(queueLength);
  Serial.println(" tasks");
  
  broadcastSystemStatus("SCHEDULE_UPDATED:" + String(queueLength));
}

// =============== Manual Control Handler ===============
void handleManualControl(String control) {
  // Manual control format: "SERVO:channel:angle"
  // Example: "SERVO:0:90" - Move servo 0 (GAMOT_A) to 90 degrees
  // Channels: 0=GAMOT_A, 1=GAMOT_B, 2=DOSAGE
  
  if (control.startsWith("SERVO:")) {
    int firstColon = control.indexOf(':');
    int secondColon = control.indexOf(':', firstColon + 1);
    
    if (firstColon != -1 && secondColon != -1) {
      int channel = control.substring(firstColon + 1, secondColon).toInt();
      int angle = control.substring(secondColon + 1).toInt();
      
      if (channel >= 0 && channel <= 2 && angle >= 0 && angle <= 180) {
        setServoAngle(channel, angle);
        Serial.print("Manual servo control: Channel ");
        Serial.print(channel);
        Serial.print(" -> ");
        Serial.print(angle);
        Serial.println(" degrees");
        
        broadcastSystemStatus("MANUAL_SERVO:" + String(channel) + ":" + String(angle));
      }
    }
  }
}

// =============== BLE Broadcasting ===============
void broadcastSensorData() {
  MAX30102Data pulseData = readMAX30102();
  DHTData dhtData = readDHT11();
  
  // JSON format: {"hr":75,"spo2":98,"temp":25.5,"hum":60.2,"fingerDetected":true}
  String jsonData = "{";
  jsonData += "\"hr\":" + String(pulseData.heartRate) + ",";
  jsonData += "\"spo2\":" + String(pulseData.spo2) + ",";
  jsonData += "\"temp\":" + String(dhtData.temperature, 1) + ",";
  jsonData += "\"hum\":" + String(dhtData.humidity, 1) + ",";
  jsonData += "\"fingerDetected\":" + String(pulseData.fingerDetected ? "true" : "false");
  jsonData += "}";
  
  if (deviceConnected) {
    pSensorDataChar->setValue(jsonData.c_str());
    pSensorDataChar->notify();
  }
  
  // Also log to Serial
  Serial.print("[Sensor Data] ");
  Serial.println(jsonData);
}

void broadcastSystemStatus(String status) {
  // JSON format: {"status":"IDLE","currentTask":0,"queueLength":3,"dosageOpen":false,"distance":10.5,"queueRunning":false}
  float dist = readDistanceCM();
  
  String jsonStatus = "{";
  jsonStatus += "\"status\":\"" + status + "\",";
  jsonStatus += "\"currentTask\":" + String(currentTask) + ",";
  jsonStatus += "\"queueLength\":" + String(queueLength) + ",";
  jsonStatus += "\"dosageOpen\":" + String(dosageCurrentAngle == 90 ? "true" : "false") + ",";
  jsonStatus += "\"distance\":" + String(dist, 1) + ",";
  jsonStatus += "\"queueRunning\":" + String(queueRunning ? "true" : "false") + ",";
  jsonStatus += "\"manualMode\":" + String(manualMode ? "true" : "false");
  jsonStatus += "}";
  
  if (deviceConnected) {
    pSystemStatusChar->setValue(jsonStatus.c_str());
    pSystemStatusChar->notify();
  }
  
  // Also log to Serial
  Serial.print("[System Status] ");
  Serial.println(jsonStatus);
}

void displayBLEStatus() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("BLE: Ready");
  display.setCursor(0, 12);
  display.println("Waiting for");
  display.setCursor(0, 24);
  display.println("connection...");
  display.display();
}

// =============== Main Loop ===============
void loop() {
  // Handle BLE connection status
  if (!deviceConnected && oldDeviceConnected) {
    delay(500);
    pServer->startAdvertising();
    Serial.println("Start advertising");
    oldDeviceConnected = deviceConnected;
  }
  
  if (deviceConnected && !oldDeviceConnected) {
    oldDeviceConnected = deviceConnected;
    Serial.println("Device connected");
  }

  // Broadcast status every 5 seconds
  if (deviceConnected && millis() - lastStatusBroadcast >= 5000) {
    lastStatusBroadcast = millis();
    broadcastSystemStatus("RUNNING");
  }

  // Skip automatic operations if in manual mode
  if (manualMode) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println("MANUAL MODE");
    display.setCursor(0, 16);
    display.println("App Control Active");
    display.display();
    delay(100);
    return;
  }

  // ======== TASK QUEUE PHASE ========
  if (queueRunning && currentTask < queueLength) {
    TaskType task = taskQueue[currentTask].taskType;
    
    // Check if task is scheduled
    if (taskQueue[currentTask].scheduledTime > 0) {
      // In a real implementation, compare with RTC time
      // For now, execute immediately
    }
    
    switch (task) {
      case GAMOT_A:
        Serial.println("[Task Queue] Starting Gamot A");
        broadcastSystemStatus("TASK_GAMOT_A_START");
        gamotAControlTask();
        Serial.println("[Task Queue] Finished Gamot A");
        broadcastSystemStatus("TASK_GAMOT_A_COMPLETE");
        break;
      case GAMOT_B:
        Serial.println("[Task Queue] Starting Gamot B");
        broadcastSystemStatus("TASK_GAMOT_B_START");
        gamotBControlTask();
        Serial.println("[Task Queue] Finished Gamot B");
        broadcastSystemStatus("TASK_GAMOT_B_COMPLETE");
        break;
    }
    taskQueue[currentTask].executed = true;
    currentTask++;
    
    // Check if queue is complete
    if (currentTask >= queueLength) {
      queueRunning = false;
      broadcastSystemStatus("QUEUE_COMPLETE");
    }
  } else {
    // Default operation when no queue is running
    dosageHatchControlTask();
    updateBuzzer();

    // OLED display
    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(0, 0);
    
    if (queueLength > 0) {
      display.print("Queue: ");
      display.print(currentTask);
      display.print("/");
      display.println(queueLength);
      display.setCursor(0, 12);
      display.println(queueRunning ? "RUNNING" : "READY");
    } else {
      display.println("No Schedule");
      display.setCursor(0, 12);
      display.println("Send from App");
    }
    
    display.setCursor(0, 24);
    display.print("Dosage: ");
    display.print(dosageCurrentAngle == 90 ? "OPEN" : "CLOSED");
    
    if (deviceConnected) {
      display.setCursor(90, 0);
      display.println("BLE");
    }
    display.display();
  }
  
  delay(100);
}

// =============== Servo Control ===============
void setServoAngle(int channel, int angle) {
  int pulse = map(angle, 0, 180, SERVO_MIN, SERVO_MAX);
  pwm.setPWM(channel, 0, pulse);
}

// =============== Task Functions ===============
void gamotAControlTask() {
  Serial.println("[Gamot A] Opening gate");
  setServoAngle(SERVO_GAMOT_A, 90);
  while (readTripwire(LDR1_PIN) == 0) delay(20);
  Serial.println("[Gamot A] Object passed → Closing gate");
  setServoAngle(SERVO_GAMOT_A, 0);
}

void gamotBControlTask() {
  Serial.println("[Gamot B] Opening gate");
  setServoAngle(SERVO_GAMOT_B, 90);
  while (readTripwire(LDR2_PIN) == 0) delay(20);
  Serial.println("[Gamot B] Object passed → Closing gate");
  setServoAngle(SERVO_GAMOT_B, 0);
}

// =============== Dosage Hatch ===============
void dosageHatchControlTask() {
  float dist = readDistanceCM();

  if (dist > 0 && dist <= 4.0) {
    if (!dosageOpened) {
      Serial.println("[Dosage Hatch] Medicine detected → Opening");
      dosageOpened = true;
      digitalWrite(BUZZER_PIN, LOW);
      broadcastSystemStatus("MEDICINE_DETECTED");
    }
    setServoAngle(SERVO_DOSAGE, 90);
    dosageCurrentAngle = 90;
  } else {
    if (dosageCurrentAngle != 0) {
      setServoAngle(SERVO_DOSAGE, 0);
      dosageCurrentAngle = 0;
    }
  }
}

// =============== Sensors & Helpers ===============
int readTripwire(int ldrPin) {
  return digitalRead(ldrPin) == LOW ? 1 : 0;
}

float readDistanceCM() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return -1;
  return duration * 0.0343 / 2;
}

void updateBuzzer() {
  static unsigned long lastBuzz = 0;
  static bool buzzerState = false;
  unsigned long currentMillis = millis();
  if (!dosageOpened && currentMillis - lastBuzz >= 200) {
    lastBuzz = currentMillis;
    buzzerState = !buzzerState;
    digitalWrite(BUZZER_PIN, buzzerState);
  }
}

// =============== DHT11 - Now callable from app ===============
DHTData readDHT11() {
  DHTData data;
  data.temperature = dht.readTemperature();
  data.humidity = dht.readHumidity();
  data.valid = !(isnan(data.temperature) || isnan(data.humidity));
  return data;
}

// =============== MAX30102 - Now callable from app ===============
void setupMAX30102() {
  if (!particleSensor.begin(Wire, I2C_SPEED_STANDARD)) {
    Serial.println("MAX30102 not found!");
    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("MAX30102 ERROR!");
    display.display();
    while (1);
  }

  particleSensor.setup(0x1F, 4, 2, 100, 411, 4096);
  particleSensor.setPulseAmplitudeRed(0x1F);
  particleSensor.setPulseAmplitudeGreen(0);

  Serial.println("MAX30102 initialized.");
}

MAX30102Data readMAX30102() {
  MAX30102Data data;
  data.fingerDetected = false;
  data.valid = false;
  data.heartRate = 0;
  data.spo2 = 0;

  long irValue = particleSensor.getIR();

  if (irValue > 50000) {
    data.fingerDetected = true;

    if (checkForBeat(irValue) == true) {
      long delta = millis() - lastBeat;
      lastBeat = millis();
      beatsPerMinute = 60000.0f / (float)delta;

      if (beatsPerMinute > 30 && beatsPerMinute < 200) {
        rates[rateSpot++] = (byte)beatsPerMinute;
        rateSpot %= RATE_SIZE;

        beatAvg = 0;
        for (byte x = 0; x < RATE_SIZE; x++) {
          beatAvg += rates[x];
        }
        beatAvg /= RATE_SIZE;
        
        data.heartRate = beatAvg;
        data.valid = true;
      }
    }

    long redValue = particleSensor.getRed();
    
    if (redValue > 10000 && irValue > 10000) {
      float ratio = (float)redValue / (float)irValue;
      int spo2Estimate = 110 - 25 * ratio;
      
      if (spo2Estimate > 85 && spo2Estimate < 100) {
        data.spo2 = spo2Estimate;
      } else {
        data.spo2 = 98;
      }
    }
  } else {
    rateSpot = 0;
    beatAvg = 0;
    for (byte x = 0; x < RATE_SIZE; x++) {
      rates[x] = 0;
    }
  }

  return data;
}